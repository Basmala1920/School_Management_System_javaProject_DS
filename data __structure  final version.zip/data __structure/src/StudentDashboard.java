import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class StudentDashboard extends JFrame {

    private Student student;
    private Admin admin; // لربط الـ AdminGUI
    private JLabel nameLabel, emailLabel, addressLabel, cityLabel, ageLabel, departmentLabel, levelLabel;
    private JTable table;
    private DefaultTableModel model;

    public StudentDashboard(Student student, Admin admin) {
        this.student = student;
        this.admin = admin;

        setVisible(true);

        setTitle("Student Dashboard - " + student.getName());
        setSize(500, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ===== Main Panel =====
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.decode("#fbeaff"));

        // ===== Info Panel =====
        JPanel infoPanel = new JPanel(new GridLayout(7, 1));
        infoPanel.setBackground(Color.decode("#fbeaff"));

        Color textColor = Color.decode("#640E0E");

        nameLabel = new JLabel("Name: " + student.getName());
        emailLabel = new JLabel("Email: " + student.getEmail());
        addressLabel = new JLabel("Address: " + student.getAddress());
        cityLabel = new JLabel("City: " + student.getCity());
        ageLabel = new JLabel("Age: " + student.getAge());
        departmentLabel = new JLabel("Department: " + student.getDepartment());
        levelLabel = new JLabel("Level: " + student.getLevel());

        JLabel[] labels = {nameLabel, emailLabel, addressLabel, cityLabel, ageLabel, departmentLabel, levelLabel};
        for (JLabel label : labels) label.setForeground(textColor);

        for (JLabel label : labels) infoPanel.add(label);

        panel.add(infoPanel, BorderLayout.NORTH);

        // ===== Table =====
        String[] columns = {"Course", "Grade"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setForeground(textColor);
        table.setBackground(Color.decode("#fbeaff"));
        table.getTableHeader().setBackground(Color.decode("#b39cd0"));
        table.getTableHeader().setForeground(textColor);

        refreshTable();

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBackground(Color.decode("#fbeaff"));
        scrollPane.getViewport().setBackground(Color.decode("#fbeaff"));
        panel.add(scrollPane, BorderLayout.CENTER);

        // ===== Buttons Panel =====
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.decode("#fbeaff"));

        JButton editButton = new JButton("Edit Profile");
        JButton logoutButton = new JButton("Logout");
        JButton adminButton = new JButton("Go to Admin Panel");




        JButton[] buttons = {editButton, logoutButton, adminButton };
        for (JButton btn : buttons) {
            btn.setBackground(Color.PINK);
            btn.setForeground(textColor);
            btn.setBorderPainted(false);
            buttonPanel.add(btn);
        }


        JButton homeButton = new JButton("Home");
        homeButton.addActionListener(e -> {
            this.dispose(); // يغلق نافذة الـ StudentDashboard الحالية
            HomeGUI home = new HomeGUI(); // يفتح الـ HomeGUI
            home.setVisible(true);
        });
        homeButton.setBackground(Color.PINK);
        homeButton.setForeground(Color.decode("#640E0E"));
        homeButton.setBorderPainted(false);
        panel.add(buttonPanel, BorderLayout.SOUTH);



        // ===== Add panel to frame =====
        add(panel);

        // ===== Button Actions =====
        editButton.addActionListener(e -> editProfile());
        logoutButton.addActionListener(e -> dispose());

        JPanel btnPanel = new JPanel();
        buttonPanel.add(homeButton);

//        buttonPanel.setBorderPainted(false);
        add(btnPanel, BorderLayout.SOUTH);







        adminButton.addActionListener(e -> {
            AdminGUI adminGUI = new AdminGUI(admin);
//            adminGUI.setVisible(true);
        });

        setVisible(true);
    }





    private void refreshTable() {
        model.setRowCount(0);
        for (String course : student.getCourses()) {
            Integer grade = student.getGrades().get(course);
            model.addRow(new Object[]{course, grade != null ? grade : "-"});
        }
    }

    private void editProfile() {
        JTextField nameField = new JTextField(student.getName());
        JTextField emailField = new JTextField(student.getEmail());
        JTextField addressField = new JTextField(student.getAddress());
        JTextField cityField = new JTextField(student.getCity());

        Object[] fields = {
                "Name:", nameField,
                "Email:", emailField,
                "Address:", addressField,
                "City:", cityField
        };

        int result = JOptionPane.showConfirmDialog(this, fields, "Edit Profile", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            student.setName(nameField.getText());
            student.setEmail(emailField.getText());
            student.setAddress(addressField.getText());
            student.setCity(cityField.getText());

            nameLabel.setText("Name: " + student.getName());
            emailLabel.setText("Email: " + student.getEmail());
            addressLabel.setText("Address: " + student.getAddress());
            cityLabel.setText("City: " + student.getCity());
        }
    }




}


































//
//
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//
//public class StudentDashboard extends JFrame {
//    private Student student;
//    private Admin admin;
//    private JLabel nameLabel, emailLabel, addressLabel, cityLabel, ageLabel, departmentLabel, levelLabel;
//    private JTable table;
//    private DefaultTableModel model;
//    private static StudentDashboard instance;
//
//    public static StudentDashboard getInstance(Student student, Admin admin) {
//        if (instance == null) {
//            instance = new StudentDashboard(student, admin);
//        }
//        return instance;
//    }
//
//    private StudentDashboard(Student student, Admin admin) {
//        this.student = student;
//        this.admin = admin;
//
//        setTitle("Student Dashboard - " + student.getName());
//        setSize(500, 450);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//
//        JPanel panel = new JPanel(new BorderLayout(10,10));
//        panel.setBackground(Color.decode("#fbeaff"));
//
//        JPanel infoPanel = new JPanel(new GridLayout(7,1));
//        infoPanel.setBackground(Color.decode("#fbeaff"));
//        Color textColor = Color.decode("#640E0E");
//
//        nameLabel = new JLabel("Name: " + student.getName());
//        emailLabel = new JLabel("Email: " + student.getEmail());
//        addressLabel = new JLabel("Address: " + student.getAddress());
//        cityLabel = new JLabel("City: " + student.getCity());
//        ageLabel = new JLabel("Age: " + student.getAge());
//        departmentLabel = new JLabel("Department: " + student.getDepartment());
//        levelLabel = new JLabel("Level: " + student.getLevel());
//
//        JLabel[] labels = {nameLabel,emailLabel,addressLabel,cityLabel,ageLabel,departmentLabel,levelLabel};
//        for (JLabel label : labels) label.setForeground(textColor);
//        for (JLabel label : labels) infoPanel.add(label);
//
//        panel.add(infoPanel, BorderLayout.NORTH);
//
//        String[] columns = {"Course","Grade"};
//        model = new DefaultTableModel(columns,0);
//        table = new JTable(model);
//        table.setForeground(textColor);
//        table.setBackground(Color.decode("#fbeaff"));
//        table.getTableHeader().setBackground(Color.decode("#b39cd0"));
//        table.getTableHeader().setForeground(textColor);
//        refreshTable();
//
//        JScrollPane scrollPane = new JScrollPane(table);
//        scrollPane.setBackground(Color.decode("#fbeaff"));
//        scrollPane.getViewport().setBackground(Color.decode("#fbeaff"));
//        panel.add(scrollPane, BorderLayout.CENTER);
//
//        JPanel buttonPanel = new JPanel(new FlowLayout());
//        buttonPanel.setBackground(Color.decode("#fbeaff"));
//
//        JButton editButton = new JButton("Edit Profile");
//        JButton logoutButton = new JButton("Logout");
//        JButton adminButton = new JButton("Go to Admin Panel");
//        JButton homeButton = new JButton("Home");
//        JButton notifBtn = new JButton("Notifications");
//
//        JButton[] buttons = {editButton, logoutButton, adminButton, homeButton, notifBtn};
//        for(JButton b : buttons){
//            b.setBackground(Color.PINK);
//            b.setForeground(textColor);
//            b.setBorderPainted(false);
//            buttonPanel.add(b);
//        }
//
//        add(panel, BorderLayout.CENTER);
//        panel.add(buttonPanel, BorderLayout.SOUTH);
//
//
//
//
//
//        editButton.addActionListener(e -> editProfile());
//        logoutButton.addActionListener(e -> dispose());
//        homeButton.addActionListener(e -> {
//            this.dispose();
//            HomeGUI.getInstance().setVisible(true);
//        });
//        adminButton.addActionListener(e -> AdminGUI.getInstance(admin).setVisible(true));
//        notifBtn.addActionListener(e -> new NotificationGUI(student.getName()));
//    }
//
//    private void refreshTable() {
//        model.setRowCount(0);
//        for(String course : student.getCourses()){
//            Integer grade = student.getGrades().get(course);
//            model.addRow(new Object[]{course, grade != null ? grade : "-"});
//        }
//    }
//
//    private void editProfile() {
//        JTextField nameField = new JTextField(student.getName());
//        JTextField emailField = new JTextField(student.getEmail());
//        JTextField addressField = new JTextField(student.getAddress());
//        JTextField cityField = new JTextField(student.getCity());
//
//        Object[] fields = {"Name:", nameField, "Email:", emailField, "Address:", addressField, "City:", cityField};
//        int result = JOptionPane.showConfirmDialog(this, fields,"Edit Profile", JOptionPane.OK_CANCEL_OPTION);
//        if(result == JOptionPane.OK_OPTION){
//            student.setName(nameField.getText());
//            student.setEmail(emailField.getText());
//            student.setAddress(addressField.getText());
//            student.setCity(cityField.getText());
//
//            nameLabel.setText("Name: "+student.getName());
//            emailLabel.setText("Email: "+student.getEmail());
//            addressLabel.setText("Address: "+student.getAddress());
//            cityLabel.setText("City: "+student.getCity());
//        }
//    }
//}
