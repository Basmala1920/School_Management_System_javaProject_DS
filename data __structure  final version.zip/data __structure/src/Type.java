public enum Type {
    GRADE,
    ATTENDANCE,
    ENROLLMENT,
    EXAM
}
