////public class TeacherGUI {
////}
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import java.util.HashMap;
//
//public class TeacherGUI extends JFrame {
//
//    private Teacher teacher;
//    private Attendance attendance;
//    private Grade grade;
//    private HashMap<String, Student> students; // مفروض عندك قائمة الطلاب
//
//    public TeacherGUI(Teacher teacher, Attendance attendance, Grade grade, HashMap<String, Student> students) {
//        this.teacher = teacher;
//        this.attendance = attendance;
//        this.grade = grade;
//        this.students = students;
//
//        setTitle("Teacher Dashboard");
//        setSize(500, 400);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLayout(new GridLayout(6, 2, 10, 10));
//
//        // Labels and TextFields
//        JLabel studentIdLabel = new JLabel("Student ID:");
//        JTextField studentIdField = new JTextField();
//
//        JLabel gradeLabel = new JLabel("Grade:");
//        JTextField gradeField = new JTextField();
//
//        // Buttons
//        JButton markAttendanceBtn = new JButton("Register Attendance");
//        JButton viewAttendanceBtn = new JButton("View Attendance");
//        JButton addGradeBtn = new JButton("Add Grade");
//        JButton viewGradeBtn = new JButton("View Grade");
//        JButton calculateAvgBtn = new JButton("Calculate Average");
//
//
//
//        JButton homeButton = new JButton("Home");
//        homeButton.addActionListener(e -> {
//            this.dispose();
//            HomeGUI home = new HomeGUI();
//            home.setVisible(true);
//        });
//
//        homeButton.setBackground(Color.PINK);
//        homeButton.setForeground(Color.decode("#640E0E"));
//        homeButton.setBorderPainted(false);
//
//        JPanel btnPanel = new JPanel();
//        btnPanel.add(homeButton);
//        add(btnPanel, BorderLayout.SOUTH);
//
//
//
//
//        JButton notifBtn = new JButton("Notifications");
//
//        notifBtn.addActionListener(e -> {
//            new NotificationGUI("Teacher");
//        });
//
//        add(notifBtn);
//
//
//
//
//        // Add components
//        add(studentIdLabel);
//        add(studentIdField);
//        add(gradeLabel);
//        add(gradeField);
//        add(markAttendanceBtn);
//        add(viewAttendanceBtn);
//        add(addGradeBtn);
//        add(viewGradeBtn);
//        add(calculateAvgBtn);
//
//        // ================= Event Listeners =================
//
//        markAttendanceBtn.addActionListener(e -> {
//            String studentId = studentIdField.getText();
//            teacher.registerAttendance(attendance, studentId);
//            JOptionPane.showMessageDialog(this, "Attendance registered for " + studentId);
//        });
//
//        viewAttendanceBtn.addActionListener(e -> {
//            teacher.viewAttendance(attendance);
//        });
//
//        addGradeBtn.addActionListener(e -> {
//            String studentId = studentIdField.getText();
//            double value;
//            try {
//                value = Double.parseDouble(gradeField.getText());
//            } catch (NumberFormatException ex) {
//                JOptionPane.showMessageDialog(this, "Enter a valid grade!");
//                return;
//            }
//            Student student = students.get(studentId);
//            if (student != null) {
//                teacher.addGrade(grade, student, value);
//                JOptionPane.showMessageDialog(this, "Grade added for " + student.getName());
//            } else {
//                JOptionPane.showMessageDialog(this, "Student not found!");
//            }
//        });
//
//        viewGradeBtn.addActionListener(e -> {
//            String studentId = studentIdField.getText();
//            Student student = students.get(studentId);
//            if (student != null) {
//                teacher.viewGrade(grade, student);
//            } else {
//                JOptionPane.showMessageDialog(this, "Student not found!");
//            }
//        });
//
//        calculateAvgBtn.addActionListener(e -> {
//            teacher.calculateAverage(grade);
//        });
//
////        setVisible(true);
//    }
//
//    // مثال على التشغيل
////    public static void main(String[] args) {
////        Teacher t = new Teacher("Ali", "ali@gmail.com", "Cairo", "Cairo", "T001", "Math");
////        Attendance attendance = new Attendance();
////        Grade grade = new Grade();
////        HashMap<String, Student> students = new HashMap<>();
////        students.put("S001", new Student("Ahmed", "ahmed@gmail.com", "Giza", "Giza", 3.5, 2, "S001", "SIM", 18));
////
////        new TeacherGUI(t, attendance, grade, students);
////    }
//}
//





























import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class TeacherGUI extends JFrame {

    private Teacher teacher;
    private Attendance attendance;
    private Grade grade;
    private HashMap<String, Student> students;

    // ===== Style (same as StudentDashboard) =====
    Color bgColor = Color.decode("#fbeaff");
    Color textColor = Color.decode("#640E0E");
    Color buttonColor = Color.PINK;

    public TeacherGUI(Teacher teacher, Attendance attendance, Grade grade, HashMap<String, Student> students) {
        this.teacher = teacher;
        this.attendance = attendance;
        this.grade = grade;
        this.students = students;

        setTitle("Teacher Dashboard");
        setSize(520, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(bgColor);

        // ===== Main Panel =====
        JPanel mainPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        mainPanel.setBackground(bgColor);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ===== Labels & Fields =====
        JLabel studentIdLabel = new JLabel("Student ID:");
        JTextField studentIdField = new JTextField();

        JLabel gradeLabel = new JLabel("Grade:");
        JTextField gradeField = new JTextField();

        JLabel[] labels = {studentIdLabel, gradeLabel};
        for (JLabel lbl : labels) {
            lbl.setForeground(textColor);
            lbl.setFont(new Font("Arial", Font.BOLD, 13));
        }

        // ===== Buttons =====
        JButton markAttendanceBtn = new JButton("Register Attendance");
        JButton viewAttendanceBtn = new JButton("View Attendance");
        JButton addGradeBtn = new JButton("Add Grade");
        JButton viewGradeBtn = new JButton("View Grade");
        JButton calculateAvgBtn = new JButton("Calculate Average");
        JButton notifBtn = new JButton("Notifications");

        JButton[] buttons = {
                markAttendanceBtn, viewAttendanceBtn,
                addGradeBtn, viewGradeBtn,
                calculateAvgBtn, notifBtn
        };

        for (JButton btn : buttons) {
            styleButton(btn);
        }

        // ===== Add Components =====
        mainPanel.add(studentIdLabel);
        mainPanel.add(studentIdField);
        mainPanel.add(gradeLabel);
        mainPanel.add(gradeField);
        mainPanel.add(markAttendanceBtn);
        mainPanel.add(viewAttendanceBtn);
        mainPanel.add(addGradeBtn);
        mainPanel.add(viewGradeBtn);
        mainPanel.add(calculateAvgBtn);
        mainPanel.add(notifBtn);

        add(mainPanel);

        // ===== Home Button =====
        JButton homeButton = new JButton("Home");
        styleButton(homeButton);

        homeButton.addActionListener(e -> {
            dispose();
            new HomeGUI().setVisible(true);
        });

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(bgColor);
        btnPanel.add(homeButton);
        add(btnPanel, BorderLayout.SOUTH);

        // ===== Notifications =====
        notifBtn.addActionListener(e -> new NotificationGUI("Teacher"));

        // ================= Event Listeners =================
        markAttendanceBtn.addActionListener(e -> {
            String studentId = studentIdField.getText();
            teacher.registerAttendance(attendance, studentId);
            JOptionPane.showMessageDialog(this, "Attendance registered for " + studentId);
        });

        viewAttendanceBtn.addActionListener(e -> {
            teacher.viewAttendance(attendance);
        });

        addGradeBtn.addActionListener(e -> {
            String studentId = studentIdField.getText();
            double value;
            try {
                value = Double.parseDouble(gradeField.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter a valid grade!");
                return;
            }

            Student student = students.get(studentId);
            if (student != null) {
                teacher.addGrade(grade, student, value);
                JOptionPane.showMessageDialog(this, "Grade added for " + student.getName());
            } else {
                JOptionPane.showMessageDialog(this, "Student not found!");
            }
        });

        viewGradeBtn.addActionListener(e -> {
            String studentId = studentIdField.getText();
            Student student = students.get(studentId);
            if (student != null) {
                teacher.viewGrade(grade, student);
            } else {
                JOptionPane.showMessageDialog(this, "Student not found!");
            }
        });

        calculateAvgBtn.addActionListener(e -> {
            teacher.calculateAverage(grade);
        });

        setVisible(true);
    }

    // ===== Button Style Method =====
    private void styleButton(JButton btn) {
        btn.setBackground(buttonColor);
        btn.setForeground(textColor);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
    }
}
