import java.awt.*;
import javax.swing.*;

 class NotificationGUI extends JFrame {

    private SchoolSystem system;
    private String role;
    private JTextArea displayArea;

    private void loadNotifications() {
        displayArea.setText("");  // clear
        Node<Notifications> current = system.getQueue(role);

        if (current == null) {
            displayArea.append("No notifications.\n");
            return;
        }

        while (current != null) {
            displayArea.append(current.data + "\n");
            current = current.next;
        }
    }


    public NotificationGUI(SchoolSystem system, String role) {
        this.system = system;
        this.role = role;

        setTitle(role.toUpperCase() + " Notifications");
        setSize(550, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());



        // ===== Colors =====
        Color bgColor = Color.decode("#fbeaff");
        Color textColor = Color.decode("#640E0E");

        getContentPane().setBackground(bgColor);

        // ===== Title =====
        JLabel title = new JLabel(role.toUpperCase() + " NOTIFICATIONS", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(textColor);
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // ===== Display Area =====
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setBackground(bgColor);
        displayArea.setForeground(textColor);
        displayArea.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        add(scrollPane, BorderLayout.CENTER);

        // ===== Buttons =====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(bgColor);

        JButton readBtn = new JButton("Read Next");
        JButton lastBtn = new JButton("Last Read");
        JButton clearBtn = new JButton("Clear History");

        JButton[] buttons = { readBtn, lastBtn, clearBtn };

        for (JButton b : buttons) {
            b.setBackground(Color.PINK);
            b.setForeground(textColor);
            b.setBorderPainted(false);
            b.setFocusPainted(false);
        }

        buttonPanel.add(readBtn);
        buttonPanel.add(lastBtn);
        buttonPanel.add(clearBtn);

        add(buttonPanel, BorderLayout.SOUTH);

        // ===== Actions =====
        readBtn.addActionListener(e -> {
            Notifications n = system.readNext(role);
            if (n == null)
                displayArea.append("No new notifications\n");
            else
                displayArea.append(n + "\n");
        });

        lastBtn.addActionListener(e -> {
            Notifications n = system.getLastRead(role);
            if (n == null)
                displayArea.append("No notifications read yet\n");
            else
                displayArea.append("Last Read: " + n + "\n");
        });

        clearBtn.addActionListener(e -> {
            system.clearHistory(role);
            displayArea.append("History cleared\n");
        });

        loadNotifications();

    }









         public NotificationGUI(String userType) {
             setTitle(userType + " Notifications");
             setSize(300, 200);
             setLocationRelativeTo(null);

             JTextArea area = new JTextArea();
             area.setEditable(false);

             if (userType.equals("Student")) {
                 area.setText(
                         "- New exam schedule\n" +
                                 "- Grade updated\n"
                 );
             } else if (userType.equals("Teacher")) {
                 area.setText(
                         "- New class assigned\n" +
                                 "- Student submitted assignment\n"
                 );
             } else if (userType.equals("Admin")) {
                 area.setText(
                         "- New student registered\n" +
                                 "- System update\n"
                 );
             }

             add(new JScrollPane(area));
             setVisible(true);
         }
     }





















