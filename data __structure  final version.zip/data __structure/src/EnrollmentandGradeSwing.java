//
//import javax.swing.*;
//import java.awt.*;
////import models.*;
//
//public class EnrollmentandGradeSwing extends JFrame {
//
//    private Grade grade;
//    private Enrollment enrollment;
//    private Student student;
//
//    private JLabel lblStudent;
//    private JTextField txtStudentName;
//
//    private JTextArea gradeDisplay;
//    private JTextArea enrolledDisplay;
//
//    private JTextField txtGrade;
//    private JTextField txtCourseName;
//    private JTextField txtCourseId;
//    private JTextField txtTeacher;
//
//    public EnrollmentandGradeSwing() {
//
//        // Sample student
//        student = new Student(
//                "Ali", "ali@mail.com", "Cairo", "Cairo",
//                3.5, 2, "S001", "CS", 20
//        );
//
//        grade = new Grade("Data Structure");
//        enrollment = new Enrollment(student);
//
//        setTitle("Enrollment & Grade GUI");
//        setSize(750, 480);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLocationRelativeTo(null);
//
//        JPanel mainPanel = new JPanel();
//        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
//        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
//
//        // ================= Student Section =================
//        JPanel studentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
//        studentPanel.setBorder(BorderFactory.createTitledBorder("Student"));
//
//        lblStudent = new JLabel("Student: " + student.getName());
//        lblStudent.setFont(new Font("Arial", Font.BOLD, 14));
//
//        txtStudentName = new JTextField(student.getName(), 10);
//        JButton btnUpdateStudent = new JButton("Update Student");
//
//        studentPanel.add(lblStudent);
//        studentPanel.add(new JLabel("New Name:"));
//        studentPanel.add(txtStudentName);
//        studentPanel.add(btnUpdateStudent);
//
//        btnUpdateStudent.addActionListener(e -> updateStudentName());
//
//        mainPanel.add(studentPanel);
//
//        // ================= Grade Section =================
//        JPanel gradePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
//        gradePanel.setBorder(BorderFactory.createTitledBorder("Grade"));
//
//        txtGrade = new JTextField(8);
//        JButton btnAddGrade = new JButton("Add / Update Grade");
//
//        gradePanel.add(new JLabel("Grade:"));
//        gradePanel.add(txtGrade);
//        gradePanel.add(btnAddGrade);
//
//        gradeDisplay = new JTextArea(4, 40);
//        gradeDisplay.setEditable(false);
//        JScrollPane gradeScroll = new JScrollPane(gradeDisplay);
//
//        btnAddGrade.addActionListener(e -> addGrade());
//
//        mainPanel.add(gradePanel);
//        mainPanel.add(gradeScroll);
//
//        // ================= Enrollment Section =================
//        JPanel enrollPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
//        enrollPanel.setBorder(BorderFactory.createTitledBorder("Enroll in Course"));
//
//        txtCourseName = new JTextField(10);
//        txtCourseId = new JTextField(8);
//        txtTeacher = new JTextField(10);
//
//        JButton btnEnroll = new JButton("Enroll");
//        JButton btnDrop = new JButton("Drop");
//
//        enrollPanel.add(new JLabel("Name:"));
//        enrollPanel.add(txtCourseName);
//        enrollPanel.add(new JLabel("ID:"));
//        enrollPanel.add(txtCourseId);
//        enrollPanel.add(new JLabel("Teacher:"));
//        enrollPanel.add(txtTeacher);
//        enrollPanel.add(btnEnroll);
//        enrollPanel.add(btnDrop);
//
//        enrolledDisplay = new JTextArea(6, 40);
//        enrolledDisplay.setEditable(false);
//        JScrollPane enrollScroll = new JScrollPane(enrolledDisplay);
//
//        btnEnroll.addActionListener(e -> enrollCourse());
//        btnDrop.addActionListener(e -> dropCourse());
//
//
//
//        JButton homeButton = new JButton("Home");
//        homeButton.addActionListener(e -> {
//            this.dispose();
//            HomeGUI home = new HomeGUI();
//            home.setVisible(true);
//        });
//
//        JPanel btnPanel = new JPanel();
//        btnPanel.add(homeButton);
//        add(btnPanel, BorderLayout.SOUTH);
//
//        mainPanel.add(enrollPanel);
//        mainPanel.add(enrollScroll);
//
//        add(mainPanel);
//    }
//
//    // ================= Methods =================
//
//    private void updateStudentName() {
//        String newName = txtStudentName.getText().trim();
//
//        if (newName.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Student name cannot be empty");
//            return;
//        }
//
//        student.setName(newName);
//        lblStudent.setText("Student: " + student.getName());
//    }
//
//    private void addGrade() {
//        try {
//            double g = Double.parseDouble(txtGrade.getText());
//
//            if (g < 0 || g > 100) {
//                JOptionPane.showMessageDialog(this, "Grade must be 0 - 100");
//                return;
//            }
//
//            grade.addGrade(student, g);
//            gradeDisplay.setText(
//                    student.getName() + " -> Grade: " + grade.getGrade(student)
//            );
//
//            txtGrade.setText("");
//
//        } catch (NumberFormatException ex) {
//            JOptionPane.showMessageDialog(this, "Enter a valid number");
//        }
//    }
//
//    private void enrollCourse() {
//        String name = txtCourseName.getText().trim();
//        String id = txtCourseId.getText().trim();
//        String teacher = txtTeacher.getText().trim();
//
//        if (name.isEmpty() || id.isEmpty() || teacher.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Fill all fields");
//            return;
//        }
//
//         CourseNode course = new CourseNode(name, id, teacher, 0);
//        enrollment.enrollCourse(course);
//
//        refreshEnrolledDisplay();
//        clearCourseFields();
//    }
//
//    private void dropCourse() {
//        String id = txtCourseId.getText().trim();
//
//        for (CourseNode c : enrollment.getEnrolledCourses()) {
//            if (c.courseId.equals(id)) {
//                enrollment.dropCourse(c);
//                break;
//            }
//        }
//        refreshEnrolledDisplay();
//    }
//
//    private void refreshEnrolledDisplay() {
//        enrolledDisplay.setText("");
//        for (CourseNode c : enrollment.getEnrolledCourses()) {
//            enrolledDisplay.append(
//                    c.courseName + " | " +
//                            c.courseId + " | " +
//                            c.teacherName + "\n"
//            );
//        }
//    }
//
//    private void clearCourseFields() {
//        txtCourseName.setText("");
//        txtCourseId.setText("");
//        txtTeacher.setText("");
//    }
//
//    // ================= Main =================
////    public static void main(String[] args) {
////        SwingUtilities.invokeLater(() ->
////                new EnrollmentandGradeSwing().setVisible(true)
////        );
////    }
//}






























import javax.swing.*;
import java.awt.*;

public class EnrollmentandGradeSwing extends JFrame {

    private Grade grade;
    private Enrollment enrollment;
    private Student student;

    private JLabel lblStudent;
    private JTextField txtStudentName;

    private JTextArea gradeDisplay;
    private JTextArea enrolledDisplay;

    private JTextField txtGrade;
    private JTextField txtCourseName;
    private JTextField txtCourseId;
    private JTextField txtTeacher;

    // ====== Style Colors (same as StudentDashboard) ======
    Color bgColor = Color.decode("#fbeaff");
    Color textColor = Color.decode("#640E0E");
    Color buttonColor = Color.PINK;

    public EnrollmentandGradeSwing() {

        // Sample student
        student = new Student(
                "Ali", "ali@mail.com", "Cairo", "Cairo",
                3.5, 2, "S001", "CS", 20
        );

        grade = new Grade("Data Structure");
        enrollment = new Enrollment(student);

        setTitle("Enrollment & Grade GUI");
        setSize(750, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(bgColor);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(bgColor);

        // ================= Student Section =================
        JPanel studentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        studentPanel.setBackground(bgColor);
        studentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(textColor),
                "Student",
                0, 0,
                new Font("Arial", Font.BOLD, 12),
                textColor
        ));

        lblStudent = new JLabel("Student: " + student.getName());
        lblStudent.setForeground(textColor);
        lblStudent.setFont(new Font("Arial", Font.BOLD, 14));

        txtStudentName = new JTextField(student.getName(), 10);

        JButton btnUpdateStudent = new JButton("Update Student");
        styleButton(btnUpdateStudent);

        studentPanel.add(lblStudent);
        studentPanel.add(new JLabel("New Name:"));
        studentPanel.add(txtStudentName);
        studentPanel.add(btnUpdateStudent);

        for (Component c : studentPanel.getComponents())
            if (c instanceof JLabel) c.setForeground(textColor);

        btnUpdateStudent.addActionListener(e -> updateStudentName());

        mainPanel.add(studentPanel);

        // ================= Grade Section =================
        JPanel gradePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        gradePanel.setBackground(bgColor);
        gradePanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(textColor),
                "Grade",
                0, 0,
                new Font("Arial", Font.BOLD, 12),
                textColor
        ));

        txtGrade = new JTextField(8);

        JButton btnAddGrade = new JButton("Add / Update Grade");
        styleButton(btnAddGrade);

        gradePanel.add(new JLabel("Grade:"));
        gradePanel.add(txtGrade);
        gradePanel.add(btnAddGrade);

        for (Component c : gradePanel.getComponents())
            if (c instanceof JLabel) c.setForeground(textColor);

        gradeDisplay = new JTextArea(4, 40);
        gradeDisplay.setEditable(false);
        gradeDisplay.setBackground(bgColor);
        gradeDisplay.setForeground(textColor);

        JScrollPane gradeScroll = new JScrollPane(gradeDisplay);
        gradeScroll.getViewport().setBackground(bgColor);

        btnAddGrade.addActionListener(e -> addGrade());

        mainPanel.add(gradePanel);
        mainPanel.add(gradeScroll);

        // ================= Enrollment Section =================
        JPanel enrollPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        enrollPanel.setBackground(bgColor);
        enrollPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(textColor),
                "Enroll in Course",
                0, 0,
                new Font("Arial", Font.BOLD, 12),
                textColor
        ));

        txtCourseName = new JTextField(10);
        txtCourseId = new JTextField(8);
        txtTeacher = new JTextField(10);

        JButton btnEnroll = new JButton("Enroll");
        JButton btnDrop = new JButton("Drop");
        styleButton(btnEnroll);
        styleButton(btnDrop);

        enrollPanel.add(new JLabel("Name:"));
        enrollPanel.add(txtCourseName);
        enrollPanel.add(new JLabel("ID:"));
        enrollPanel.add(txtCourseId);
        enrollPanel.add(new JLabel("Teacher:"));
        enrollPanel.add(txtTeacher);
        enrollPanel.add(btnEnroll);
        enrollPanel.add(btnDrop);

        for (Component c : enrollPanel.getComponents())
            if (c instanceof JLabel) c.setForeground(textColor);

        enrolledDisplay = new JTextArea(6, 40);
        enrolledDisplay.setEditable(false);
        enrolledDisplay.setBackground(bgColor);
        enrolledDisplay.setForeground(textColor);

        JScrollPane enrollScroll = new JScrollPane(enrolledDisplay);
        enrollScroll.getViewport().setBackground(bgColor);

        btnEnroll.addActionListener(e -> enrollCourse());
        btnDrop.addActionListener(e -> dropCourse());

        mainPanel.add(enrollPanel);
        mainPanel.add(enrollScroll);

        // ================= Home Button =================
        JButton homeButton = new JButton("Home");
        styleButton(homeButton);
        homeButton.addActionListener(e -> {
            dispose();
            new HomeGUI().setVisible(true);
        });

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(bgColor);
        btnPanel.add(homeButton);

        add(mainPanel);
        add(btnPanel, BorderLayout.SOUTH);
    }

    // ================= Styling Method =================
    private void styleButton(JButton btn) {
        btn.setBackground(buttonColor);
        btn.setForeground(textColor);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
    }

    // ================= Methods =================
    private void updateStudentName() {
        String newName = txtStudentName.getText().trim();
        if (newName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Student name cannot be empty");
            return;
        }
        student.setName(newName);
        lblStudent.setText("Student: " + student.getName());
    }

    private void addGrade() {
        try {
            double g = Double.parseDouble(txtGrade.getText());
            if (g < 0 || g > 100) {
                JOptionPane.showMessageDialog(this, "Grade must be 0 - 100");
                return;
            }
            grade.addGrade(student, g);
            gradeDisplay.setText(student.getName() + " -> Grade: " + grade.getGrade(student));
            txtGrade.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter a valid number");
        }
    }

    private void enrollCourse() {
        String name = txtCourseName.getText().trim();
        String id = txtCourseId.getText().trim();
        String teacher = txtTeacher.getText().trim();

        if (name.isEmpty() || id.isEmpty() || teacher.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill all fields");
            return;
        }

        CourseNode course = new CourseNode(name, id, teacher, 0);
        enrollment.enrollCourse(course);
        refreshEnrolledDisplay();
        clearCourseFields();
    }

    private void dropCourse() {
        String id = txtCourseId.getText().trim();
        for (CourseNode c : enrollment.getEnrolledCourses()) {
            if (c.courseId.equals(id)) {
                enrollment.dropCourse(c);
                break;
            }
        }
        refreshEnrolledDisplay();
    }

    private void refreshEnrolledDisplay() {
        enrolledDisplay.setText("");
        for (CourseNode c : enrollment.getEnrolledCourses()) {
            enrolledDisplay.append(
                    c.courseName + " | " +
                            c.courseId + " | " +
                            c.teacherName + "\n"
            );
        }
    }

    private void clearCourseFields() {
        txtCourseName.setText("");
        txtCourseId.setText("");
        txtTeacher.setText("");
    }
}









