import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class HomeGUI extends JFrame {

    public HomeGUI() {
        setTitle("Home Page");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ==== Sample objects ====
//        Student s1 = new Student("Ali", "ali@mail.com", "Cairo", "Cairo",
//                3.5, 2, "S001", "CS", 20);
        Student s1 = new Student("emo", "emo@gmail.com", "Damanhour", "ElBehiera", 3.5, 2, "2406005", "SIM", 18);
        s1.addCourse("Math"); s1.addCourse("Physics"); s1.addCourse("Programming");
        s1.addGrade("Math", 85); s1.addGrade("Physics", 90); s1.addGrade("Programming", 95);


                Student s2 = new Student("Fatom", "Fatom@gmail.com", "ELSadat", "Monofiia", 3.75, 2, "2406203", "SIM", 19);
        s2.addCourse("History"); s2.addCourse("Science"); s2.addCourse("OOP");
        s2.addGrade("History", 85); s2.addGrade("Science", 90); s2.addGrade("OOP", 95);

        Student s3 = new Student("Basbosa", "Basbosa@gmail.com", "Alex", "Alexandria", 3.57, 2, "2406234", "SIM", 20);
        s3.addCourse("Arabic"); s3.addCourse("Probability"); s3.addCourse("UI");
        s3.addGrade("Arabic", 85); s3.addGrade("Probability", 90); s3.addGrade("UI", 95);



        Admin admin = new Admin();

        Teacher t1 = new Teacher("Mr. Ahmed", "ahmed@mail.com", "Cairo", "Cairo", "T001", "Math");
        Attendance attendance = new Attendance(admin); // لازم يكون عندك كلاس Attendance
        Grade grade = new Grade("Math");
        HashMap<String, Student> studentsMap = new HashMap<>();
        studentsMap.put(s1.getId(), s1);

        // ==== Panel and Buttons ====
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 10, 10));

        JButton teacherBtn = new JButton("Teacher");
        JButton adminBtn = new JButton("Admin");
        JButton studentBtn = new JButton("Student");
        JButton enrollmentBtn = new JButton("Enrollment");

        panel.add(teacherBtn);
        panel.add(adminBtn);
        panel.add(studentBtn);
        panel.add(enrollmentBtn);

        add(panel);






        adminBtn.addActionListener(e -> {
            AdminGUI adminGUI = new AdminGUI(admin);
            adminGUI.setVisible(true);
        });

        studentBtn.addActionListener(e -> {
            StudentDashboard studentGUI = new StudentDashboard(s1, admin);
            studentGUI.setVisible(true);
        });

        enrollmentBtn.addActionListener(e -> {
            EnrollmentandGradeSwing enrollmentGUI = new EnrollmentandGradeSwing();
            enrollmentGUI.setVisible(true);
        });

        teacherBtn.addActionListener(e -> {
            TeacherGUI teacherGUI = new TeacherGUI(t1, attendance, grade, studentsMap);
            teacherGUI.setVisible(true);
        });



    }

//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> {
//            HomeGUI home = new HomeGUI();
//            home.setVisible(true);
//        });
//    }
}

