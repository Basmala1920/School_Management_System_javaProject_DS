import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminGUI extends JFrame {
    private Admin admin;
    private JTextArea displayArea;

    public AdminGUI(Admin admin) {
        this.admin = admin;

        setTitle("Admin Panel");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ===== Display Area =====
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        add(scrollPane, BorderLayout.CENTER);




        // ===== Buttons Panel =====
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(8, 1, 5, 5));

        // Add Buttons
        JButton addStudentBtn = new JButton("Add Student");
        JButton deleteStudentBtn = new JButton("Delete Student");
        JButton viewStudentsBtn = new JButton("View Students");

        JButton addTeacherBtn = new JButton("Add Teacher");
        JButton deleteTeacherBtn = new JButton("Delete Teacher");
        JButton viewTeachersBtn = new JButton("View Teachers");

        JButton addExamBtn = new JButton("Add Exam");
        JButton viewExamsBtn = new JButton("View Exams");

        addStudentBtn.setBackground(Color.PINK);
        deleteTeacherBtn.setBackground(Color.PINK);
        viewStudentsBtn.setBackground(Color.PINK);
        addTeacherBtn.setBackground(Color.PINK);
        deleteTeacherBtn.setBackground(Color.PINK);
        viewTeachersBtn.setBackground(Color.PINK);
        addExamBtn.setBackground(Color.PINK);
        viewExamsBtn.setBackground(Color.PINK);
        deleteStudentBtn.setBackground(Color.PINK);

        addStudentBtn.setForeground(Color.decode("#640E0E"));
        deleteStudentBtn.setForeground(Color.decode("#640E0E"));
        viewStudentsBtn.setForeground(Color.decode("#640E0E"));
        addTeacherBtn.setForeground(Color.decode("#640E0E"));
        deleteTeacherBtn.setForeground(Color.decode("#640E0E"));
        viewTeachersBtn.setForeground(Color.decode("#640E0E"));
        addExamBtn.setForeground(Color.decode("#640E0E"));
        viewExamsBtn.setForeground(Color.decode("#640E0E"));


        addStudentBtn .setBorderPainted(false);
        deleteStudentBtn.setBorderPainted(false);
        viewStudentsBtn.setBorderPainted(false);
        addTeacherBtn.setBorderPainted(false);
        deleteTeacherBtn.setBorderPainted(false);
        viewTeachersBtn.setBorderPainted(false);
        addExamBtn.setBorderPainted(false);
        viewExamsBtn.setBorderPainted(false);




        JButton homeButton = new JButton("Home");
        homeButton.addActionListener(e -> {
            this.dispose();
            HomeGUI home = new HomeGUI();
            home.setVisible(true);
        });

        homeButton.setBackground(Color.PINK);
        homeButton.setForeground(Color.decode("#640E0E"));
        homeButton.setBorderPainted(false);

        JPanel btnPanel = new JPanel();
        buttonPanel.add(homeButton);
        add(btnPanel, BorderLayout.SOUTH);





        JButton notifBtn = new JButton("Notifications");
        notifBtn.addActionListener(e -> {
            new NotificationGUI("Admin");
        });

        add(notifBtn);



        // Add buttons to panel
        buttonPanel.add(addStudentBtn);
        buttonPanel.add(deleteStudentBtn);
        buttonPanel.add(viewStudentsBtn);
        buttonPanel.add(addTeacherBtn);
        buttonPanel.add(deleteTeacherBtn);
        buttonPanel.add(viewTeachersBtn);
        buttonPanel.add(addExamBtn);
        buttonPanel.add(viewExamsBtn);

        add(buttonPanel, BorderLayout.WEST);

        // ===== Button Actions =====
        addStudentBtn.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Enter student name:");
            String id = JOptionPane.showInputDialog("Enter student ID:");
            if(name != null && id != null) {
                admin.addStudent(name, id);
                JOptionPane.showMessageDialog(this, "Student added!");
            }
        });

        deleteStudentBtn.addActionListener(e -> {
            String id = JOptionPane.showInputDialog("Enter student ID to delete:");
            if(id != null) {
                admin.deleteStudent(id);
                JOptionPane.showMessageDialog(this, "Student deleted if exists!");
            }
        });

        viewStudentsBtn.addActionListener(e -> {
            displayArea.setText(""); // clear
            displayArea.setForeground(Color.decode("#640E0E"));
            displayArea.setBackground(Color.decode("#fbeaff"));
            StudentNode current = admin.studentHead;
            while(current != null) {
                displayArea.append("Name: " + current.studentName +
                        " | ID: " + current.studentId + "\n");
                current = current.next;
            }
        });

        addTeacherBtn.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Enter teacher name:");
            String id = JOptionPane.showInputDialog("Enter teacher ID:");
            String courseId = JOptionPane.showInputDialog("Enter course ID:");
            if(name != null && id != null && courseId != null) {
                admin.addTeacher(name, id, courseId);
                JOptionPane.showMessageDialog(this, "Teacher added!");
            }
        });

        deleteTeacherBtn.addActionListener(e -> {
            String id = JOptionPane.showInputDialog("Enter teacher ID to delete:");
            if(id != null) {
                admin.deleteTeacher(id);
                JOptionPane.showMessageDialog(this, "Teacher deleted if exists!");
            }
        });

        viewTeachersBtn.addActionListener(e -> {
            displayArea.setText(""); // clear
            TeacherNode current = admin.teacherHead;
            while(current != null) {
                displayArea.append("Name: " + current.teacherName +
                        " | ID: " + current.teacherId +
                        " | CourseID: " + current.courseId + "\n");
                current = current.next;
            }
        });

        addExamBtn.addActionListener(e -> {
            String courseName = JOptionPane.showInputDialog("Enter course name:");
            String courseId = JOptionPane.showInputDialog("Enter course ID:");
            String date = JOptionPane.showInputDialog("Enter date:");
            String room = JOptionPane.showInputDialog("Enter room:");
            String time = JOptionPane.showInputDialog("Enter time:");
            if(courseName != null && courseId != null && date != null && room != null && time != null) {
                admin.addExam(courseName, courseId, date, room, time);
                JOptionPane.showMessageDialog(this, "Exam added!");
            }
        });

        viewExamsBtn.addActionListener(e -> {
            displayArea.setText(""); // clear
            ExamNode current = admin.examHead;
            while(current != null) {
                displayArea.append("Course: " + current.courseName +
                        " | ID: " + current.courseId +
                        " | Date: " + current.date +
                        " | Room: " + current.room +
                        " | Time: " + current.time + "\n");
                current = current.next;
            }
        });
    }




}































//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//
//public class AdminGUI extends JFrame {
//    private Admin admin;
//    private JTextArea displayArea;
//    private static AdminGUI instance; // لتجنب تكرار النوافذ
//
//    public static AdminGUI getInstance(Admin admin) {
//        if (instance == null) {
//            instance = new AdminGUI(admin);
//        }
//        return instance;
//    }
//
//    private AdminGUI(Admin admin) {
//        this.admin = admin;
//
//        setTitle("Admin Panel");
//        setSize(600, 500);
//        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        setLayout(new BorderLayout());
//
//        displayArea = new JTextArea();
//        displayArea.setEditable(false);
//        JScrollPane scrollPane = new JScrollPane(displayArea);
//        add(scrollPane, BorderLayout.CENTER);
//
//        JPanel buttonPanel = new JPanel();
//        buttonPanel.setLayout(new GridLayout(8, 1, 5, 5));
//
//        JButton addStudentBtn = new JButton("Add Student");
//        JButton deleteStudentBtn = new JButton("Delete Student");
//        JButton viewStudentsBtn = new JButton("View Students");
//        JButton addTeacherBtn = new JButton("Add Teacher");
//        JButton deleteTeacherBtn = new JButton("Delete Teacher");
//        JButton viewTeachersBtn = new JButton("View Teachers");
//        JButton addExamBtn = new JButton("Add Exam");
//        JButton viewExamsBtn = new JButton("View Exams");
//
//        JButton homeButton = new JButton("Home");
//        homeButton.addActionListener(e -> {
//            this.dispose();
//            HomeGUI home = HomeGUI.getInstance(); // هنعمل HomeGUI Singleton
//            home.setVisible(true);
//        });
//
//        JButton notifBtn = new JButton("Notifications");
//        notifBtn.addActionListener(e -> new NotificationGUI("Admin"));
//
//        buttonPanel.add(homeButton);
//        buttonPanel.add(addStudentBtn);
//        buttonPanel.add(deleteStudentBtn);
//        buttonPanel.add(viewStudentsBtn);
//        buttonPanel.add(addTeacherBtn);
//        buttonPanel.add(deleteTeacherBtn);
//        buttonPanel.add(viewTeachersBtn);
//        buttonPanel.add(addExamBtn);
//        buttonPanel.add(viewExamsBtn);
//        buttonPanel.add(notifBtn);
//
//        add(buttonPanel, BorderLayout.WEST);
//
//        // ===== Button Actions =====
//        addStudentBtn.addActionListener(e -> {
//            String name = JOptionPane.showInputDialog("Enter student name:");
//            String id = JOptionPane.showInputDialog("Enter student ID:");
//            if(name != null && id != null) {
//                admin.addStudent(name, id);
//                JOptionPane.showMessageDialog(this, "Student added!");
//            }
//        });
//
//        deleteStudentBtn.addActionListener(e -> {
//            String id = JOptionPane.showInputDialog("Enter student ID to delete:");
//            if(id != null) {
//                admin.deleteStudent(id);
//                JOptionPane.showMessageDialog(this, "Student deleted if exists!");
//            }
//        });
//
//        viewStudentsBtn.addActionListener(e -> {
//            displayArea.setText("");
//            StudentNode current = admin.studentHead;
//            while(current != null) {
//                displayArea.append("Name: " + current.studentName + " | ID: " + current.studentId + "\n");
//                current = current.next;
//            }
//        });
//
//        addTeacherBtn.addActionListener(e -> {
//            String name = JOptionPane.showInputDialog("Enter teacher name:");
//            String id = JOptionPane.showInputDialog("Enter teacher ID:");
//            String courseId = JOptionPane.showInputDialog("Enter course ID:");
//            if(name != null && id != null && courseId != null) {
//                admin.addTeacher(name, id, courseId);
//                JOptionPane.showMessageDialog(this, "Teacher added!");
//            }
//        });
//
//        deleteTeacherBtn.addActionListener(e -> {
//            String id = JOptionPane.showInputDialog("Enter teacher ID to delete:");
//            if(id != null) {
//                admin.deleteTeacher(id);
//                JOptionPane.showMessageDialog(this, "Teacher deleted if exists!");
//            }
//        });
//
//        viewTeachersBtn.addActionListener(e -> {
//            displayArea.setText("");
//            TeacherNode current = admin.teacherHead;
//            while(current != null) {
//                displayArea.append("Name: " + current.teacherName + " | ID: " + current.teacherId +
//                        " | CourseID: " + current.courseId + "\n");
//                current = current.next;
//            }
//        });
//
//        addExamBtn.addActionListener(e -> {
//            String courseName = JOptionPane.showInputDialog("Enter course name:");
//            String courseId = JOptionPane.showInputDialog("Enter course ID:");
//            String date = JOptionPane.showInputDialog("Enter date:");
//            String room = JOptionPane.showInputDialog("Enter room:");
//            String time = JOptionPane.showInputDialog("Enter time:");
//            if(courseName != null && courseId != null && date != null && room != null && time != null) {
//                admin.addExam(courseName, courseId, date, room, time);
//                JOptionPane.showMessageDialog(this, "Exam added!");
//            }
//        });
//
//        viewExamsBtn.addActionListener(e -> {
//            displayArea.setText("");
//            ExamNode current = admin.examHead;
//            while(current != null) {
//                displayArea.append("Course: " + current.courseName + " | ID: " + current.courseId +
//                        " | Date: " + current.date + " | Room: " + current.room + " | Time: " + current.time + "\n");
//                current = current.next;
//            }
//        });
//    }
//}
